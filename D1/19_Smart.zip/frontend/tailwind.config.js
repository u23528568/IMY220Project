module.exports = {
  content: ["./src/**/*.{js,jsx}", "./frontend/public/index.html"],
  theme: {
    extend: {},
  },
  plugins: [],
};
